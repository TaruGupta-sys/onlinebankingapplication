package g;


import java.util.*;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      Scanner sc= new Scanner(System.in);
	}

}
